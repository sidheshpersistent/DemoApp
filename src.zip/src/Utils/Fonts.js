const Fonts = {
  Thin: 'Inter-Thin',
  Light: 'Inter-Light',
  Regular: 'Inter-Regular',
  Medium: 'Inter-Medium',
  SemiBold: 'Inter-SemiBold',
  Bold: 'Inter-Bold',
  Skia: 'Skia',
};
export default Fonts;
