import styled from 'styled-components/native';

export const HeaderContainer = styled.View`
  flex-direction: row;
  padding: 20px;
`;
export const BackArrowStyle = {
  with: 30,
  height: 30,
};
