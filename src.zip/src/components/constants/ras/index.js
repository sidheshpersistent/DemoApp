/* eslint-disable import/prefer-default-export */
import * as constants from './constants';

export const CONSTANTS = constants;
