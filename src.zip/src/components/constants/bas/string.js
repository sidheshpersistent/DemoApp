const BAS = {
  ACCESS_MANAGEMENT: 'Access management',
  DOORSTEP_BANKING: 'Doorstep banking',
  SERVICE_REQUEST: 'Service requests',
  APPROVALS: 'Approvals',
  CHEQUEBOOK_MANAGEMENT: 'Chequebook Management',
};

export default BAS;
