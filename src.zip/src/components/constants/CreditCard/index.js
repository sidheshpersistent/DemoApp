import * as constants from './constants';
import apiUrls from './apiUrls';

export const CREDIT_CARD_URLS = apiUrls;
export const CONSTANTS = constants;
