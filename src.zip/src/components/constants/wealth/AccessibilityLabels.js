const accessibilityLabels = {
  SGB_HOLDINGS_SHARE: 'Double tap to share certificates',
};

export default accessibilityLabels;
