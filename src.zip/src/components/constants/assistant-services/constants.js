export const VIDEO = 'Video';
export const CHAT = 'Chat';
