export const ERROR_MESSAGE_API_KEY_HEADER = 'Error-Messaging-Api-Key';
export const REFERER_HEADER = 'Error-Messaging-Api-Key';
