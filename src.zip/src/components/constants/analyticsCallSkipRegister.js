export default {
  login_check: 'login_check',
  intermediateLogin: 'intermediateLogin',
};
