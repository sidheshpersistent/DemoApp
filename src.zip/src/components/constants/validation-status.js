const VALIDATION_STATES = {
  ERROR: 'error',
  VERIFY_ERROR: 'verify_error',
  ERROR_POPUP: 'error_popup',
  SUCCESS: 'success',
  WARNING: 'warning',
};

export default VALIDATION_STATES;
