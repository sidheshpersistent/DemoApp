import constants from './constants';

const CONSTANTS = constants;

export default CONSTANTS;
