const BrandHeroSize = {
  SIZE_220: 220,
  SIZE_125: 125,
  SIZE_90: 90,
};

export default BrandHeroSize;
