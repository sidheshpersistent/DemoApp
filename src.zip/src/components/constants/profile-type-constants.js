export default {
  BUSINESS: 'BIB',
  RETAIL: 'RIB',
  ASSET: 'RIB - Asset Only',
  CREDIT_CARD: 'CREDITCARD',
};
