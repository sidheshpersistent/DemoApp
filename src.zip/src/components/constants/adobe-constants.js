export const ADOBE_TARGET_MBOX_NAME = 'app-global-mbox';
export const ADOBE_TARGET_MBOX_LIST = [
  'dashboard-B1',
  'dashboard-B2',
  'pay_history_transactions',
  'savings_account_list',
  'fixed_deposit_list',
  'deposits',
  'loanListing',
  'recurring_deposit_list',
  'echeques',
  'doorstep_banking',
  'create_od_against_fd',
];
