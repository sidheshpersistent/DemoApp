export const TRANSACTION_TYPE = 'default';

export default TRANSACTION_TYPE;
