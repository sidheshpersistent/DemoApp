const HPEDestination = {
  ACCOUNTS_LIST: 'savings_account_list',
  DEPOSITS_LIST: 'deposits',
  FIXED_DEPOSIT_LIST: 'fixed_deposit_list',
  RECURRING_DEPOSIT_LIST: 'recurring_deposit_list',
};

export default HPEDestination;
