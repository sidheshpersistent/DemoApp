import LocalizedStrings from 'react-native-localization';
import en from './en.json';

const Labels = new LocalizedStrings({ en });

export default Labels;
