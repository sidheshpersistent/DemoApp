
import en from './en.json';

const Labels ={
  en,
};

export default Labels;
