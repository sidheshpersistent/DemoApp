import LocalizedStrings from 'react-native-localization';
import errors from './errors.json';

const WealthErrorMessages = new LocalizedStrings(errors);

export default WealthErrorMessages;
