import LocalizedStrings from 'react-native-localization';
import en from './en.json';

const noAadharLabel = new LocalizedStrings({
  en,
});

export default noAadharLabel;
