import React, {useEffect, useState} from 'react';
import {
    View,
    Text,
    Image,
    TouchableOpacity,
    Dimensions,
    Button,
  } from 'react-native';
  import {ScrollView} from 'react-native-gesture-handler';

  const CustomerConsent = (props) =>{

    return (
       <View style={{flex:1}}>
         <Text>ayush</Text>
         </View>
    )
  }
  export default CustomerConsent;