import React, {useEffect, useState} from 'react';
import {View, Text, Image, TouchableOpacity} from 'react-native';
import Popup from '../../components/Popup/Popup';
import styled from 'styled-components/native';
import PopUpExistingCustomer from '../../components/Popup/PopUpExistingCustomer';
import PopupTextInput from '../../components/Popup/PopupTextInput';
import PopupCommunicationAddress from '../../components/Popup/PopupCommunicationAddress';
const icon = require('../../assets/info.png');
const alertIcon = require('../../assets/alertIcon.png');
const HEADING = {
  PAN_MANDATORY: 'When is it mandatory to enter PAN?',
  PAN_CHECK: 'Sorry!  Customer must provide PAN to open account.',
  MOBILE_CHECK: 'Please provide another mobile number to proceed further',
  EMAIL_CHECK: 'Please provide another email address to proceed further',
};

var PAN_INCOME_CHECK = [
  'Customer is below 60 years of age and gross annual income is above ₹2.5 lacs',
  'Customer is between 60-79 years of age and gross annual income is above ₹3 lacs ',
  'Customer is aged 80 years or above and gross annual income is above ₹5 lacs',
];

{
  /** TODO: popup info to be deleted later as it would come from backend*/
}
const POPUP_INFO = {
  PAN_CHECK_INFO:
    'It is mandatory for customers below 60 years of age to provide PAN if their income is above ₹2.5Lacs ',
  MOBILE_CHECK_INFO:
    'The mobile number entered already exists in the Bank under the Customer ID: *****6471 Name: Vicky Patilas fetched from CBS/MDM.',
  EMAIL_CHECK_INFO:
    'The email address entered already exists in the Ban under the Customer ID: *****6471 and Name: Vicky Patil as fetched from CBS/MDM.',
};

import {NEWCOMMUNICATIONADDRESS, EDITBRANCH} from '../../constants/constants';
import PopupEditBranch from '../../components/Popup/PopupEditBranch';

const ModelTestScreen = props => {
  const [isVisible, setIsvisible] = useState(false);
  const [mobile, setMobile] = useState(false);
  const [pan, setPan] = useState(false);
  const [email, setEmail] = useState(false);
  const [isVisible3, setIsvisible3] = useState(false);
  const [number, setNumber] = useState('');
  const [panIncomeInfo, setPanIncomeInfo] = useState(PAN_INCOME_CHECK);
  const [communicationAddress, setCommunicationAddress] = useState(false);
  const [editbranch, setEditbranch] = useState(false);

  const buttonPress = () => {
    setIsvisible(false);
  };

  const buttonPress2 = () => {
    setMobile(false);
  };
  const buttonPress3 = () => {
    setPan(false);
  };
  const buttonPress4 = () => {
    setEmail(false);
  };

  const buttonPressed3 = () => {
    setIsvisible3(false);
  };

  const closeCAModal = () => {
    setCommunicationAddress(false);
  };

  const closeEBModal = () => {
    setEditbranch(false);
  };

  return (
    <View style={{flex: 1}}>
      <TouchableOpacity
        style={{alignSelf: 'flex-end'}}
        onPress={() => props.navigation.navigate('CustomerProfile')}>
        <Text>Navigate to Next</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={() => setIsvisible(true)}>
        <Text style={{fontSize: 40}}>PAN SALARY CHECK</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={() => setMobile(true)}>
        <Text style={{fontSize: 40}}>Popup For Mobile Input</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={() => setPan(true)}>
        <Text style={{fontSize: 40}}>Popup For PAN Input</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={() => setEmail(true)}>
        <Text style={{fontSize: 40}}>Popup For email Input</Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={() => setIsvisible3(true)}>
        <Text style={{fontSize: 40}}>
          Popup with existing bank account details
        </Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={() => setCommunicationAddress(true)}>
        <Text style={{fontSize: 30, marginTop: 30}}>
          NEW COMMUNICATION ADDRESS
        </Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={() => setEditbranch(true)}>
        <Text style={{fontSize: 30, marginTop: 30}}>EDIT BRANCH POPUP</Text>
      </TouchableOpacity>
      {/** PAN SALARY CHECK */}

      <Popup
        animationIn="bounceIn"
        popupIcon={icon}
        isVisible={isVisible}
        Heading={HEADING.PAN_MANDATORY}
        ButtonText="Ok"
        buttonPress={() => buttonPress()}
        component={panIncomeInfo.map(item => (
          <ComponentContainer key={item}>
            <Bullet>•</Bullet>
            <ComponentText>{item}</ComponentText>
          </ComponentContainer>
        ))}
      />

      {/* Popup For Mobile Input */}
      {mobile ? (
        <PopupTextInput
          popupType="mobile"
          animationIn="bounceIn"
          popupIcon={alertIcon}
          isVisible={mobile}
          Heading={HEADING.MOBILE_CHECK} //TODO: Heading is assumed to be taken from constants
          popupInfo={POPUP_INFO.MOBILE_CHECK_INFO}
          TextInputPlaceholder=""
          ButtonText="Submit"
          TextInputvalue={number}
          onchangeText={setNumber}
          buttonPress={() => buttonPress2()}
        />
      ) : null}

      {pan ? (
        <PopupTextInput
          popupType="pan"
          animationIn="bounceIn"
          popupIcon={alertIcon}
          isVisible={pan}
          Heading={HEADING.PAN_CHECK} // Heading is assumed to be taken from constants
          popupInfo={POPUP_INFO.PAN_CHECK_INFO}
          TextInputPlaceholder=""
          ButtonText="Submit"
          TextInputvalue={number}
          onchangeText={setNumber}
          buttonPress={() => buttonPress3()}
        />
      ) : null}
      {email ? (
        <PopupTextInput
          popupType="email"
          animationIn="bounceIn"
          popupIcon={alertIcon}
          isVisible={email}
          Heading={HEADING.EMAIL_CHECK} // Heading is assumed to be taken from constants
          popupInfo={POPUP_INFO.EMAIL_CHECK_INFO}
          TextInputPlaceholder=""
          ButtonText="Submit"
          TextInputvalue={number}
          onchangeText={setNumber}
          buttonPress={() => buttonPress4()}
        />
      ) : null}

      <PopUpExistingCustomer
        animationIn="bounceIn"
        popupIcon={icon}
        isVisible={isVisible3}
        heading="The application already has a banking relationship with us"
        subText={`The following accounts exist under the Customer ID *****6471 `}
        popupInfo="The following account exist under the customer ID *****6471."
        data={data}
        ButtonText="Confirm"
        TextInputvalue={number}
        buttonPress={buttonPressed3}
      />

      {communicationAddress ? (
        <PopupCommunicationAddress
          popupType="communication_address"
          animationIn="bounceIn"
          popupIcon={require('../../assets/icon_24_location.png')}
          isVisible={communicationAddress}
          Heading={NEWCOMMUNICATIONADDRESS.NCA_FORM_HEADING} // Heading is assumed to be taken from constants
          popupInfo={NEWCOMMUNICATIONADDRESS.NCA_SUB_HEADING}
          isActive={false}
          isValue={false}
          TextInputPlaceholder=""
          textColor="black"
          // maxLength={10}
          ButtonText="Confirm"
          buttonPress={data => {
            closeCAModal();
            console.log(data);
          }}
          CancelButtonText="Cancel"
          cancelButtonPress={() => closeCAModal()}
          isError={false}
          error_text={'validation failed'}
        />
      ) : null}

      {editbranch ? (
        <PopupEditBranch
          popupType="edit_branch"
          animationIn="bounceIn"
          popupIcon={require('../../assets/icon_24_location.png')}
          isVisible={editbranch}
          Heading={EDITBRANCH.EB_FORM_HEADING} // Heading is assumed to be taken from constants
          popupInfo={EDITBRANCH.EB_SUB_HEADING}
          isActive={false}
          isValue={false}
          TextInputPlaceholder=""
          textColor="black"
          // maxLength={10}
          ButtonText="Confirm"
          buttonPress={data => {
            closeEBModal();
            console.log(data);
          }}
          CancelButtonText="Cancel"
          cancelButtonPress={() => closeEBModal()}
          isError={false}
          error_text={'validation failed'}
        />
      ) : null}
    </View>
  );
};

const data = {
  accountList: [
    {
      accountType: 'Type 1',
      accountNumber: '******5415',
    },
    {
      accountType: 'Type 2',
      accountNumber: '******4579',
    },
  ],
  customerID: '****6471',
  mobileNumber: '+91 7085762345',
  offerList: [
    {
      ID: '1',
      reason: 'Better offers on Card',
    },
    {
      ID: '2',
      reason: 'PPF account',
    },
  ],
};
const ComponentContainer = styled.View`
  flex-direction: row;
`;

const Bullet = styled.Text`
  font-size: 18px;
  font-weight: bold;
  color: #25243b;
`;
const ComponentText = styled.Text`
  padding-left: 10px;
  margin-bottom: 20px;
  font-family: Inter;
  font-size: 16px;
  font-weight: normal;
  font-style: normal;
  line-height: 24px;

  color: #25243b;
`;

export default ModelTestScreen;
