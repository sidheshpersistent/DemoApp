export const DASHBOARD_CODE={
    TOTAL_HIGHLIGHT:"#e1e1eb",
    SUCCESS_HIGHLIGHT:"#cae7d0",
    PENDING_HIGHLIGHT:"#fcedb7"
}

export const POPUP_GRADIENT={
    LEFT:'#d1451a',
    RIGHT:'#e9a56a'
}